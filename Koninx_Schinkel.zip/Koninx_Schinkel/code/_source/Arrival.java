public class Arrival extends Event{
	public Arrival(double timeEvent, Tram tram){
		super(timeEvent);
		this.tram=tram;
	}

}